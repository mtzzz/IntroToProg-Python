'''
course: IT FDN 100 A Spring 2017
assignment: 6
date created: 05/15/17
name: Mario Totten
description: a program that reads a "ToDo list." The ToDo file will contain two columns of data (Task, Priority) 
User can add, delete, save. 
Program utilizes classes and dictionaries


'''
##  Data
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
lstTable = []


##   Processing
class Tasks():
    @staticmethod
    def ReadDoc():
        ToDo = open("Todo.txt","r")
        for line in ToDo:
            archdic = {}
            T = line.split(",")
            archdic["Task"] = T[0]
            archdic["Priority"] = T[1].strip()
            lstTable.append(dic)
            ToDo.close()

    # Step 2
    # Display a menu of choices to the user
    @staticmethod
    def DisplayOptions():
        # Display choices for user
        print("Choose 1 to Add a new item")
        print("Choose 2 to Remove an existing item")
        print("Choose 3 to Exit Program")

    # Step 3
    # Display all todo items to user
    @staticmethod
    def PrintTasks():
        # Display results
        print("These are your chores with priority: ", lstTable)
        for dict in lstTable:
            print("Task:", dict["Task"], "|", dict["Priority"])
        print()

    # Step 4
    # Add a new item to the list/Table
    @staticmethod
    def AddItem():
    # User inputs
        newDict = {}  # Declare new dictionary
        newDict["Task"] = input("Enter a new task: ")  # Set value for the Task key
        newDict["Priority"] = input("Choose a priority level (high, low): ")  # set value for Priority key
        lstTable.append(newDict)
        print(newDict["Task"] + " was added to the list\n")


    # Step 5
    # Remove a new item to the list/Table
    @staticmethod
    def RemoveItem():
        # User input to request deletion
        tasktoDel = input("List chore to remove: ")
        # Delete list element
        for dic in lstTable:
            if dic["Task"].lower() == remove.lower():
                lstTable.remove(dic)
                print(dic["Chore"], "was removed\n")


    # Step 6
    # Save tasks to the ToDo.txt file
    # Step 7
    # Exit program
    @staticmethod
    def SaveDoc():
        # Open file
        exit = input("Would you like to save? (y/n): ")
        if exit == "y":
            docTodoWrite = open("Todo.txt", "w")
            for dic in lstTable:
                docTodoWrite.write(dic["Task"] + "," + dic["Priority"] + "\n")
            docTodoWrite.close()
            print("Data was saved to Todo.txt")
        else: print("nothing was saved, goodbye!")



    @staticmethod
    def Choose():
        Choice = int(input("Please select: (1/2/3)"))
        return Choice


##   PRESENTATION

Tasks.ReadDoc()
Tasks.PrintTasks()
Tasks.DisplayOptions()
while True:
    choice = Tasks.Choose()
    if choice == "1":
        Tasks.AddItem()
        Tasks.PrintTasks()
    elif choice == "2":
        Tasks.RemoveItem()
        Tasks.PrintTasks()
    elif choice == "3":
        Tasks.SaveDoc()
        break
    else: print("Please try again.")

'''
course: IT FDN 100 A Spring 2017
assignment: 5
date created: 05/07/17
name: Mario Totten
description: a program that manages a "ToDo list." The ToDo file will contain two columns of data (Task, Priority) 
which you will store in a Python dictionary. Each Dictionary will represent one row of data. 
Which will then be added to a Python List to create a table of data.  
Menu of options provided for data. 

'''


# Create a text file called ToDo.txt
# Open the file and write two requested chores with priority.  Post writing: close txt.
ToDo = open("ToDo.txt", "w")
ToDo.write("Clean House,low\n")
ToDo.write("Pay Bills,high\n")
ToDo.close()

# Load each row of data from ToDo.txt into a Python dictionary.
# Open the file to read from
ToDo = open("ToDo.txt", "r")
# Create dictionary
dic = {}
# Set a loop for file and assign values to the dictionary
for line in ToDo:
    T = line.split(",")
    X = T[0]
    Y = T[1]
    Y = Y.strip("\n")
    dic[X] = Y
# Convert the dictionary to a list
lstTable = [dic]
# Display the results
print(lstTable)


while True:
    # Display choices for user
    print("Choose 1 to Show current data")
    print("Choose 2 to Add a new item")
    print("Choose 3 to Remove an existing item")
    print("Choose 4 to Save data to the Todo.txt file")
    print("Choose 5 to Exit Program")
    # Prompt user input
    Choice = int(input("Please select: (1/2/3/4/5)"))
    # Add task
    if Choice == 1:
        # Display results
        print("These are your chores with priority: ", lstTable)
        continue
    elif Choice == 2:
        # User inputs
        TaskNew = input("Enter a new Task: ")
        PriorityNew = input("Enter a new Priority: ")
        lstRowNew = [TaskNew, PriorityNew]
        # Add new row
        lstTable.append(lstRowNew)
        # Display results
        print("These are your chores with priority: ", lstTable)
        continue
    elif Choice == 3:
        # User input to request deletion
        tasktoDel = input("List chore to remove: ")
        # Delete list element
        if (tasktoDel in dic): del dic[tasktoDel]
        else:print("Can't locate item\n")
        # Display results
        print("These are your chores with priority: ", lstTable)
        continue
    elif Choice == 4:
        # Open file
        ToDo = open("ToDo.txt", "w")
        # Convert list to string
        strTable = str(lstTable)
        # Write list to file
        ToDo.write(strTable)
        # Save and close file
        ToDo.close()
        print("Your data has been saved.")
        continue
    elif Choice == 5:
        print("exiting.")
        break
    else:
        print("Please try again.")
        continue